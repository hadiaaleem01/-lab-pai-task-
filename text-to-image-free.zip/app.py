from flask import Flask, render_template, request
from diffusers import StableDiffusionPipeline
import torch
import os
import uuid

app = Flask(__name__)

model_id = "runwayml/stable-diffusion-v1-5"

pipe = StableDiffusionPipeline.from_pretrained(
    model_id,
    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
)

pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")

OUTPUT_FOLDER = "static/outputs"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    image_path = None

    if request.method == "POST":
        prompt = request.form["prompt"]

        image = pipe(prompt).images[0]

        filename = f"{uuid.uuid4()}.png"
        file_path = os.path.join(OUTPUT_FOLDER, filename)
        image.save(file_path)

        image_path = "/" + file_path

    return render_template("index.html", image_path=image_path)

if __name__ == "__main__":
    app.run(debug=True)
